// Runtime/LegacySoModel/ChoiceData.cs
using System;

/// <summary>
/// Representa una opci�n de di�logo dentro de un nodo de elecci�n.
/// Cada opci�n tiene un texto visible y un identificador de puerto �nico
/// que se usa para conectar con otros nodos del di�logo.
/// </summary>
[Serializable]
public class ChoiceData
{
    /// <summary>Texto que ver� el jugador en la elecci�n.</summary>
    public string choiceText;

    /// <summary>Nombre interno del puerto de salida asociado a esta opci�n.</summary>
    public string portName;
}
