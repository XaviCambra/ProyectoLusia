// Runtime/LegacySoModel/CharacterAnchor.cs
/// <summary>
/// Posici�n del personaje durante el di�logo (usado por el editor y el runtime).
/// </summary>
public enum CharacterAnchor
{
    Left,      // Personaje a la izquierda de la pantalla
    Center,    // Personaje centrado
    Right,     // Personaje a la derecha
    Custom     // Posici�n personalizada mediante coordenadas (Vector2)
}
