﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using System.Threading;
using TMPro;

public class DialogueRunner : MonoBehaviour
{
    [Header("Graph")]
    public DialogueGraph graph;

    [Header("Controles")]
    public KeyCode advanceKey = KeyCode.N;
    public KeyCode restartKey = KeyCode.R;

    [Header("UI (asigna tus elementos)")]
    public TextMeshProUGUI speakerText;
    public TextMeshProUGUI bodyText;
    [Tooltip("Botones de elección (hasta 4) en orden.")]
    public Button[] choiceButtons;

    public event Action OnDialogueEnd;

    private readonly Dictionary<string, DialogueNodeData> _nodeByGuid = new();
    private readonly Dictionary<(string fromGuid, string fromPort), string> _edgeLookup = new();
    private readonly Dictionary<string, int> _incomingCount = new();

    private enum LogicalPos { None, Left, Center, Right, OffLeft, OffRight }
    private struct PortraitState
    {
        public LogicalPos logical;   // última “posición lógica” conocida
        public Vector3 screenPos;    // última posición real en pantalla
    }
    private readonly Dictionary<string, PortraitState> _portraitStateByProfile = new();

    // --- Typewriter ---
    private readonly TypewriterService _typewriter = new();
    private CancellationTokenSource _twCts;

    private DialogueNodeData _current;
    private bool _waitingChoice;

    // Profile character service
    private ICharacterProfileService _profiles;

    [Header("Localización (opcional)")]
    [SerializeField] private MonoBehaviour localizationServiceRef;
    private ILocalizationService _loc;

    // Referencias UI (ajústalas a tu caso real)
    [Header("UI (opcional)")]
    //[SerializeField] private Text nameText;        // o TMP_Text si usas TMP
    [SerializeField] private Image portraitImage;  // si tienes retrato en UI

    // --- Retratos por perfil (pool dinámico) ---
    [Header("Portraits (pool)")]
    [Tooltip("Contenedor (RectTransform) donde se instancian y gestionan los retratos de cada personaje.")]
    [SerializeField] private RectTransform portraitsRoot;

    [Tooltip("Plantilla (Image) desactivada que se clona para cada perfil detectado.")]
    [SerializeField] private Image portraitPrefab;

    private readonly Dictionary<string, Image> _portraitByProfile = new();

    // Áncoras lógicas de posición (ajústalas a tu layout)
    [Header("Anchors de posición")]
    [Tooltip("Posición destino a la izquierda para las animaciones de entrada/salida.")]
    [SerializeField] private RectTransform leftAnchor;

    [Tooltip("Posición destino centrada para colocar al personaje en pantalla.")]
    [SerializeField] private RectTransform centerAnchor;

    [Tooltip("Posición destino a la derecha para las animaciones de entrada/salida.")]
    [SerializeField] private RectTransform rightAnchor;
    // --- END Retratos por perfil (pool dinámico) ---

    private void Awake()
    {
        // 1) Resolver servicio de perfiles primero
        // REVISAR
        _profiles = FindObjectOfType<CharacterProfileService>();

        // resolver servicio de localización
        _loc = (localizationServiceRef as ILocalizationService) ?? FindAnyObjectByType<CsvLocalizationService>();

        // 2) Validar y arrancar diálogo
        //if (!ValidateGraph()) return;
        //BuildLookups();
        //StartDialogue();

        if (!ValidateGraph()) return;
        BuildLookups();
        BuildPortraitPool();   // NUEVO: crea/activa 1 Image por perfil usado en el graph
        StartDialogue();
    }

    private void OnDestroy()
    {
        _twCts?.Cancel();
        _twCts?.Dispose();
        _twCts = null;
    }

    private void Update()
    {
        if (_current == null) return;

        if (Input.GetKeyDown(restartKey))
        {
            StartDialogue();
            return;
        }

        if (_waitingChoice) return;

        if (!_current.isChoiceNode && Input.GetKeyDown(advanceKey))
        {
            GoNext();
        }
    }

    private bool ValidateGraph()
    {
        if (graph == null)
        {
            Debug.LogError("[DialogueRunner] No hay DialogueGraph asignado.");
            return false;
        }

        _nodeByGuid.Clear();

        foreach (var n in graph.Nodes)
        {
            if (n == null || string.IsNullOrEmpty(n.GUID)) continue;
            if (!_nodeByGuid.ContainsKey(n.GUID))
                _nodeByGuid.Add(n.GUID, n);
        }

        if (_nodeByGuid.Count == 0)
        {
            Debug.LogError("[DialogueRunner] El graph no contiene nodos válidos.");
            return false;
        }

        return true;
    }

    private void BuildLookups()
    {
        _edgeLookup.Clear();
        _incomingCount.Clear();

        foreach (var guid in _nodeByGuid.Keys)
            _incomingCount[guid] = 0;

        foreach (var e in graph.Edges)
        {
            if (e == null || string.IsNullOrEmpty(e.fromNodeGUID) || string.IsNullOrEmpty(e.toNodeGUID))
                continue;

            var fromPort = string.IsNullOrEmpty(e.fromPortName) ? "Next" : e.fromPortName;
            var edgeKey = (fromGuid: e.fromNodeGUID, fromPort: fromPort);

            if (_edgeLookup.ContainsKey(edgeKey))
            {
                Debug.LogWarning($"[DialogueRunner] Puerto duplicado: {edgeKey.fromGuid}:{edgeKey.fromPort}. " +
                                 $"Ya existe conexión hacia GUID={_edgeLookup[edgeKey]}. Ignorando adicional.");
                continue;
            }

            _edgeLookup[edgeKey] = e.toNodeGUID;
            _incomingCount[e.toNodeGUID] = _incomingCount.GetValueOrDefault(e.toNodeGUID) + 1;
        }
    }

    private void ApplyNodeToUI(DialogueNodeData node)
    {
        //if (portraitImage == null) return; // si no usas retratos en UI, no hacemos nada
        //Debug.LogWarning("HAY PORTRAITIMAGE");
        //Sprite sprite = null;

        //if (node != null && _profiles != null && !string.IsNullOrEmpty(node.profileId))
        //{
        //    Debug.LogWarning("PASA LOS VERIFICADORES");

        //    var profile = _profiles.GetById(node.profileId);
        //    if (profile != null)
        //    {
        //        // 1) retrato pedido explícito por el nodo
        //        if (!string.IsNullOrEmpty(node.portraitKey))
        //            sprite = profile.GetPortraitByKey(node.portraitKey);

        //        // 2) si no hay, intenta "Default"
        //        if (sprite == null)
        //            sprite = profile.GetPortraitByKey("Default");

        //        // 3) si sigue sin haber, coge el primero que exista
        //        if (sprite == null)
        //        {
        //            var firstKey = profile.GetPortraitKeys().FirstOrDefault();
        //            if (!string.IsNullOrEmpty(firstKey))
        //                sprite = profile.GetPortraitByKey(firstKey);
        //        }
        //    }
        //}

        //portraitImage.sprite = sprite;
        //portraitImage.enabled = sprite != null; // oculta la imagen si no hay sprite
        // Si no hay pool y solo usas legacy, aplica al portraitImage y sal
        if ((_portraitByProfile == null || _portraitByProfile.Count == 0) && portraitImage == null) return;

        Sprite sprite = null;

        if (node != null && _profiles != null && !string.IsNullOrEmpty(node.profileId))
        {
            var profile = _profiles.GetById(node.profileId);

            if (profile != null)
            {
                if (!string.IsNullOrEmpty(node.portraitKey))
                    sprite = profile.GetPortraitByKey(node.portraitKey);
                if (sprite == null)
                    sprite = profile.GetPortraitByKey("Default");
                if (sprite == null)
                {
                    var firstKey = profile.GetPortraitKeys().FirstOrDefault();
                    if (!string.IsNullOrEmpty(firstKey))
                        sprite = profile.GetPortraitByKey(firstKey);
                }
            }
        }

        // 1) Legacy (si no hay pool)
        if ((_portraitByProfile == null || _portraitByProfile.Count == 0) && portraitImage != null)
        {
            portraitImage.sprite = sprite;
            portraitImage.enabled = sprite != null;
            return;
        }

        // 2) Pool por perfil
        if (!string.IsNullOrEmpty(node.profileId) && _portraitByProfile.TryGetValue(node.profileId, out var img))
        {
            img.sprite = sprite;
            img.enabled = sprite != null;
        }
    }


    private void StartDialogue()
    {
        DialogueNodeData start = null;

        // 1) Prioriza flag isStart
        var starts = _nodeByGuid.Values.Where(n => n.isStart).ToList();
        if (starts.Count > 1)
            Debug.LogWarning($"[DialogueRunner] Hay {starts.Count} nodos marcados como inicio; se usará el primero.");

        if (starts.Count >= 1)
            start = starts[0];

        // 2) Si no hay isStart, elige uno sin entradas
        if (start == null)
            start = _nodeByGuid.Values.FirstOrDefault(n => _incomingCount.TryGetValue(n.GUID, out var c) && c == 0);

        // 3) Fallback absoluto: el primero que exista
        if (start == null)
            start = _nodeByGuid.Values.First();

        SetCurrent(start);
    }

    private void SetCurrent(DialogueNodeData node)
    {
        // 0) Actualizar referencia actual y limpiar estado
        _current = node;
        _waitingChoice = false;
        HideChoices(); // por si venimos de un nodo de elección

        // 1) Speaker (nombre)
        if (speakerText) speakerText.text = GetSpeakerName(_current);

        // 2) ¿El texto empieza antes de la animación o después?
        bool startTextNow = _current != null && _current.textStart == TextStartTiming.BeforeAnimation;

        // 3) Sprite del perfil del nodo
        ApplyNodeToUI(_current);

        // 4) Anim / Placement
        RunCharacterPlacement(_current, onAnimDone: () =>
        {
            // 4.1) Mostrar el texto si estaba esperando al final de la animación
            if (!startTextNow)
                DisplayNodeBodyAsync(_current);

            // 4.2) Si este nodo es de elección, mostramos las opciones ahora
            if (_current != null && _current.isChoiceNode)
                ShowChoices(_current);
        });

        // 5) Si el texto debe empezar ANTES de la animación:
        if (startTextNow)
            DisplayNodeBodyAsync(_current);

        // 6) Si el nodo no es de elección, nos quedamos a la espera de la tecla avanzar/edges
        // (la lógica de Update y GoNext ya se encarga)
    }

    private void RunCharacterPlacement(DialogueNodeData node, Action onAnimDone)
    {
        // Si no hay perfil o pool, o target = Keep, no hacemos nada (solo callback)
        if (node == null || string.IsNullOrEmpty(node.profileId) ||
            _portraitByProfile == null || !_portraitByProfile.TryGetValue(node.profileId, out var img) ||
            img == null || node.target == MovementTarget.Keep)
        {
            onAnimDone?.Invoke();
            return;
        }

        // Elegir ancla destino según target
        RectTransform targetAnchor = null;
        switch (node.target)
        {
            case MovementTarget.Left: targetAnchor = leftAnchor; break;
            case MovementTarget.Center: targetAnchor = centerAnchor; break;
            case MovementTarget.Right: targetAnchor = rightAnchor; break;
            case MovementTarget.Out: targetAnchor = null; break; // salida
        }

        // Preparar fade helpers
        CanvasGroup cg = img.GetComponent<CanvasGroup>();
        if (cg == null) cg = img.gameObject.AddComponent<CanvasGroup>();

        // Colocaciones iniciales según 'appearance'
        var rt = img.rectTransform;

        // Entrada
        if (node.appearance == AppearanceMode.SlideIn && node.target != MovementTarget.Out)
        {
            // sitúalo fuera en el lateral indicado
            Vector3 startPos = targetAnchor != null ? targetAnchor.position : rt.position;
            float width = Screen.width * 0.6f; // heurística; puedes parametrizar si quieres

            if (node.entrySide == Side.Left) startPos.x -= width;
            else startPos.x += width;

            rt.position = startPos;

            // opacidad entrada
            float from = 1f, to = 1f;
            if (node.useFade)
            {
                from = Mathf.Clamp01(node.enterFromOpacity / 100f);
                to = Mathf.Clamp01(node.enterToOpacity / 100f);
            }
            cg.alpha = from;

            // animación hacia el anchor
            if (targetAnchor != null)
                StartCoroutine(SlideAndFade(rt, cg, targetAnchor.position, to, node.moveSpeed, onAnimDone));
            else
                StartCoroutine(SlideAndFade(rt, cg, rt.position, to, node.moveSpeed, onAnimDone));
        }
        else
        {
            // Preplaced o Out (sin entrada)
            if (node.target == MovementTarget.Out)
            {
                // salida hacia lateral
                Vector3 endPos = rt.position;
                float width = Screen.width * 0.6f;
                if (node.exitSide == Side.Left) endPos.x -= width; else endPos.x += width;

                float from = 1f, to = 1f;
                if (node.useFade)
                {
                    from = Mathf.Clamp01(node.exitFromOpacity / 100f);
                    to = Mathf.Clamp01(node.exitToOpacity / 100f);
                }
                cg.alpha = from;

                StartCoroutine(SlideAndFade(rt, cg, endPos, to, node.moveSpeed, onAnimDone));
            }
            else
            {
                // Colocar directamente donde toque (sin anim)
                if (targetAnchor != null) rt.position = targetAnchor.position;

                // set opacidad directa
                if (node.useFade)
                    cg.alpha = Mathf.Clamp01(node.enterToOpacity / 100f);
                else
                    cg.alpha = 1f;

                onAnimDone?.Invoke();
            }
        }
    }

    private System.Collections.IEnumerator SlideAndFade(RectTransform rt, CanvasGroup cg, Vector3 endPos, float endAlpha, float speed, Action onDone)
    {
        // Movimiento lineal a 'speed' px/s + Lerp de alpha
        Vector3 startPos = rt.position;
        float startAlpha = cg.alpha;

        // Si speed ~ 0, teletransporte
        if (speed <= 1f)
        {
            rt.position = endPos;
            cg.alpha = endAlpha;
            onDone?.Invoke();
            yield break;
        }

        float totalDist = Vector3.Distance(startPos, endPos);
        float t = 0f;
        while (t < 1f)
        {
            // p = v * dt / d
            float step = (speed * Time.deltaTime) / Mathf.Max(1f, totalDist);
            t = Mathf.Clamp01(t + step);

            rt.position = Vector3.Lerp(startPos, endPos, t);
            cg.alpha = Mathf.Lerp(startAlpha, endAlpha, t);

            yield return null;
        }

        onDone?.Invoke();
    }


    private void BuildPortraitPool()
    {
        if (portraitsRoot == null || portraitPrefab == null) return;

        // Limpiar previos
        foreach (var kv in _portraitByProfile)
            if (kv.Value) Destroy(kv.Value.gameObject);
        _portraitByProfile.Clear();

        // Perfiles únicos usados en nodos del graph
        var uniqueProfiles = graph.Nodes
            .Where(n => n != null && !string.IsNullOrEmpty(n.profileId))
            .Select(n => n.profileId)
            .Distinct();

        // AQUI FALTABA UNA COSA
        foreach (var pid in uniqueProfiles)
        {
            var img = Instantiate(portraitPrefab, portraitsRoot);
            img.gameObject.name = $"Portrait_{pid}";
            img.gameObject.SetActive(true);
            img.enabled = false; // hasta que tenga sprite
                                 // Colocación inicial: lo dejamos centrado; el nodo dictará target/anims.
            var rt = img.rectTransform;
            if (centerAnchor != null)
            {
                rt.position = centerAnchor.position;
            }
            _portraitByProfile[pid] = img;
            _portraitStateByProfile[pid] = new PortraitState { logical = LogicalPos.None, screenPos = img.rectTransform.position };
        }

        // Si mantenemos support para portraitImage "legacy", lo ocultamos por defecto:
        if (portraitImage) { portraitImage.enabled = false; }
    }

    private async void DisplayNodeBodyAsync(DialogueNodeData node)
    {
        if (bodyText == null)
            return;

        // Texto resuelto (localización incluida)
        string nodeText = ResolveBodyText(node);

        // Si no hay Typewriter, mostrar instantáneo
        // (si tu DialogueNodeData aún no tiene useTypewriter, añade ese bool en tu modelo)
        if (node == null || !node.useTypewriter)
        {
            bodyText.SetText(nodeText);
            return;
        }

        // Preparar CTS y cancelar la animación previa si la hubiera
        _twCts?.Cancel();
        _twCts?.Dispose();
        _twCts = new CancellationTokenSource();

        // Construir perfil desde los overrides del nodo (mínimo y claro)
        var p = ScriptableObject.CreateInstance<TypewriterProfile>();
        p.secondsPerChar = node.tw.secondsPerChar;
        p.globalSpeed = node.tw.globalSpeed;
        p.respectRichText = node.tw.respectRichText;
        p.minimalWhitespaceDelay = node.tw.minimalWhitespaceDelay;

        // pausas comunes (si no las tienes en tu struct, elimínalas o añádelas)
        p.commaPct = node.tw.commaPct;
        p.periodPct = node.tw.periodPct;
        p.ellipsisPct = node.tw.ellipsisPct;

        try
        {
            await _typewriter.RunAsync(nodeText, p, bodyText, null, _twCts.Token);
            // Al terminar de escribir, si el nodo actual es de elección y seguimos en él, muestra opciones
            if (_current == node && node.isChoiceNode)
            {
                ShowChoices(node);
            }
        }
        catch (OperationCanceledException)
        {
            // Cambio de nodo/skip: ignorar
        }
    }


    private string ResolveBodyText(DialogueNodeData node)
    {
        if (node == null) return string.Empty; // seguridad

        // si el nodo usa clave localizada
        if (node.localization && !string.IsNullOrEmpty(node.locKey) && _loc != null)
        {
            if (_loc.TryGet(node.locKey, out var localizedText))
                return localizedText;
            else
                Debug.LogWarning($"[DialogueRunner] Clave de localización no encontrada: {node.locKey}");
        }

        return GetNodeText(node);
    }

    private void ShowChoices(DialogueNodeData node)
    {
        _waitingChoice = true;

        for (int i = 0; i < choiceButtons.Length; i++)
        {
            var btn = choiceButtons[i];
            if (btn == null) continue;
            btn.onClick.RemoveAllListeners();

            if (node.choices != null && i < node.choices.Count)
            {
                var choice = node.choices[i];
                var txt = btn.GetComponentInChildren<TextMeshProUGUI>();
                if (txt) txt.text = string.IsNullOrEmpty(choice.choiceText) ? $"Opción {i + 1}" : choice.choiceText;

                var port = string.IsNullOrEmpty(choice.portName) ? $"choice_{i}" : choice.portName;
                btn.onClick.AddListener(() => OnChoiceSelected(node.GUID, port));
                btn.gameObject.SetActive(true);
            }
            else
            {
                btn.gameObject.SetActive(false);
            }
        }
    }

    private void HideChoices()
    {
        foreach (var b in choiceButtons)
            if (b) b.gameObject.SetActive(false);
    }

    private void OnChoiceSelected(string fromGuid, string fromPort)
    {
        _waitingChoice = false;
        var key = (fromGuid, fromPort);

        if (_edgeLookup.TryGetValue(key, out var toGuid) && _nodeByGuid.TryGetValue(toGuid, out var toNode))
            SetCurrent(toNode);
        else
            EndDialogue();
    }

    private void GoNext()
    {
        if (_current == null) return;

        var key = (_current.GUID, "Next");
        if (_edgeLookup.TryGetValue(key, out var toGuid) && _nodeByGuid.TryGetValue(toGuid, out var toNode))
        {
            SetCurrent(toNode);
            return;
        }

        var fallback = _edgeLookup.FirstOrDefault(kv => kv.Key.fromGuid == _current.GUID).Value;
        if (!string.IsNullOrEmpty(fallback) && _nodeByGuid.TryGetValue(fallback, out var to2))
            SetCurrent(to2);
        else
            EndDialogue();
    }

    private void EndDialogue()
    {
        HideChoices();
        if (speakerText) speakerText.text = "";
        if (bodyText) bodyText.text = "<i>(Fin del diálogo)</i>";

        if (portraitImage)
        {
            portraitImage.sprite = null;
            portraitImage.enabled = false;
        }

        // Ocultar todos los retratos del pool
        foreach (var kv in _portraitByProfile)
        {
            if (kv.Value)
            {
                kv.Value.enabled = false;
                var cg = kv.Value.GetComponent<CanvasGroup>();
                if (cg) cg.alpha = 0f;
            }
        }

        _current = null;
        _waitingChoice = false;
        OnDialogueEnd?.Invoke();
    }

    // --- Helpers de compatibilidad de nombres ---
    private static string GetNodeText(object node)
        => TryGetStringField(node, "text", "lineText", "dialogueText", "dialogText", "content", "body");

    private static string GetSpeakerName(object node)
        => TryGetStringField(node, "speakerName", "speaker", "character", "name");
    //private string GetSpeakerName(DialogueNodeData node)
    //{
    //    if (node == null) return string.Empty;

    //    if (_profiles != null && !string.IsNullOrEmpty(node.profileId))
    //    {
    //        var profile = _profiles.GetById(node.profileId);
    //        if (profile != null && !string.IsNullOrEmpty(profile.displayName))
    //            return profile.displayName; // prioriza el nombre del perfil
    //    }

    //    return node.speakerName; // fallback al del nodo
    //}

    private static string TryGetStringField(object obj, params string[] names)
    {
        if (obj == null) return "";
        var t = obj.GetType();
        foreach (var n in names)
        {
            var f = t.GetField(n);
            if (f != null && f.FieldType == typeof(string))
                return (string)(f.GetValue(obj) ?? "");
            var p = t.GetProperty(n);
            if (p != null && p.PropertyType == typeof(string))
                return (string)(p.GetValue(obj) ?? "");
        }
        return "";
    }

    private Vector3 AnchorToPos(RectTransform anchor, RectTransform fallbackRT)
    => anchor != null ? anchor.position : (fallbackRT != null ? fallbackRT.position : Vector3.zero);

    private Vector3 OffscreenPosFor(Side side, Vector3 around, float widthFactor = 0.6f)
    {
        float dx = Screen.width * widthFactor;
        return side == Side.Left ? new Vector3(around.x - dx, around.y, around.z)
                                 : new Vector3(around.x + dx, around.y, around.z);
    }

    private LogicalPos TargetToLogical(MovementTarget t)
    {
        return t switch
        {
            MovementTarget.Left => LogicalPos.Left,
            MovementTarget.Center => LogicalPos.Center,
            MovementTarget.Right => LogicalPos.Right,
            MovementTarget.Out => LogicalPos.None,
            _ => LogicalPos.None
        };
    }

}
